# Profile Card UI Design
## [Watch it on youtube](https://youtu.be/M_eF5oUzilg)
### Profile Card UI Design

- Profile Card UI Design Using HTML CSS & JavaScript
- Animated profile card with social media.
- With a beautiful minimalist interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/c/Bedimcode)

![preview img](/preview.png)
